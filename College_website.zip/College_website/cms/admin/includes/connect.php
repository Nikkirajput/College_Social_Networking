<?php 
$con = mysqli_connect("localhost","root","","socialcms");
if (!$con)
  {
  die('Could not connect: ' . mysqli_connect_error());
  }
?>