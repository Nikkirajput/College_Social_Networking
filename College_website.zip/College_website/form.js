
function validate() {
    let un = document.getElementById("username").value
    let em = document.getElementById("email").value
    let mb = document.getElementById("mobile").value
    let ps = document.getElementById("password").value
    let cp = document.getElementById("cpassword").value  
                                                        // netligent_trainer@gmail.com
    let usercheck = /^[A-Za-z.0-9]{3,30}$/
    let emailcheck = /^[A-Za-z_0-9.]{3,30}@[A-Za-z]{3,20}[.]{1}[A-Za-z.]{2,4}$/
    let mobilecheck = /^[789][0-9]{9}$/
    let passwordcheck = /^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{8,16}$/
    // let mobilecheck = /[0-9]{10}$/

    if (usercheck.test(un)) {
        document.getElementById('usererror').innerHTML = " "
    }
    else {
        let unrb = document.getElementById('username')
        document.getElementById('usererror').innerHTML = "**Username is invalid.. "
        unrb.classList.add('rb')
        return false
    }
    if (emailcheck.test(em)) {
        document.getElementById('emailerror').innerHTML = " "
    }
    else {
        let emrb = document.getElementById('email')
        document.getElementById('emailerror').innerHTML = "**Email is invalid.. "
        emrb.classList.add('rb')
        return false
    }

    if (mobilecheck.test(mb)) {
        document.getElementById('mobileerror').innerHTML = " "
    }
    else {
        let mbrb = document.getElementById('mobile')
        document.getElementById('mobileerror').innerHTML = "**Mobile number is invalid.. "
        mbrb.classList.add('rb')
        return false
    }

    if (passwordcheck.test(ps)) {
        document.getElementById('passworderror').innerHTML = " "
    }
    else {
        let psrb = document.getElementById('password')
        document.getElementById('passworderror').innerHTML = "**Password is invalid.. "
        psrb.classList.add('rb')
        return false 
    }
    if (passwordcheck.test(cp)) {
        document.getElementById('cpassworderror').innerHTML = " "
    }
    else {
        let cprb = document.getElementById('cpassword')
        document.getElementById('cpassworderror').innerHTML = "**Password is invalid.. "
        cprb.classList.add('rb')
        return false 
    }

    if (ps.match(cp)) {
        document.getElementById('cpassworderror').innerHTML = " "
    }
    else {
        let cprb = document.getElementById('cpassword')
        document.getElementById('cpassworderror').innerHTML = "**Password not match.. "
        cprb.classList.add('rb')
        return false 
    }
}
